#include "Scene.h"
#include "DirLight.h"
#include "PointLight.h"
#include "Sphere.h"

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <random>
#include <string>

#define STB_IMAGE_IMPLEMENTATION  // only place once in one .cpp file
#include "stb_image.h"

#define STB_IMAGE_WRITE_IMPLEMENTATION  // only place once in one .cpp files
#include "stb_image_write.h"

Scene::Scene(std::istream &input) {
  srand(444);
  camera = {
      .p = vec3(0, 0, 0),
      .d = vec3(0, 0, -1),
      .u = vec3(0, 1, 0),
      .r = vec3(1, 0, 0),
      .ha = M_PI_4,
  };
  focal_plane = 0.;
  aperture = 0.;
  depth_of_field = 0.;
  resolution = {.width = 640, .height = 480};
  focal_length = 0;
  supersample = 0;
  shadow_samples = 0;
  blur_samples = 0;
  output_file = "raytraced.bmp";

  background = {.r = 0, .g = 0, .b = 0};
  material_t current_material = {
      .a = {.r = 0, .g = 0, .b = 0},
      .d = {.r = 1, .g = 1, .b = 1},
      .s = {.r = 0, .g = 0, .b = 0},
      .ns = 5,
      .t = {.r = 0, .g = 0, .b = 0},
      .ior = 1,
      .e = {.r = 0, .g = 0, .b = 0},
  };
  vec3 current_blur = vec3();
  ambient_light = {.r = 0, .g = 0, .b = 0};
  max_depth = 5;

  std::string command;
  while (input >> command) {
    std::string line;
    // printf("command = %s\n", command.c_str());
    if (command[0] == '#') {
      std::getline(input, line);  // skip rest of line
      continue;
    }

    if (command == "camera_pos:") {
      double x,y,z;
      input >> x >> y >> z;
      vec3 p = vec3(x,y,z);
      camera.p = p;
    } else if (command == "camera_fwd:") {
      double x,y,z;
      input >> x >> y >> z;
      vec3 f = vec3(x,y,z);
      camera.d = f;
    } else if (command == "camera_up:") {
      double x,y,z;
      input >> x >> y >> z;
      vec3 u = vec3(x,y,z);
      camera.u = u;
    } else if (command == "camera_fov_ha:") {
      double ha;
      input >> ha;
      camera.ha = ha * M_PI / 180;
      camera.d.Normalize();
      camera.u.Normalize();
      camera.r = vec3::Cross(camera.u, camera.d).Normalized();
      camera.u = vec3::Cross(camera.d, camera.r).Normalized();
    } else if (command == "film_resolution:") {
      input >> resolution.width >> resolution.height;
    } else if (command == "output_image:") {
      input >> output_file;
    } else if (command == "sphere:") {
      double x, y, z, r;
      input >> x >> y >> z >> r;
      Sphere *s =
          new Sphere(vec3(x, y, z), r, current_material, current_blur);
      shapes.push_back(s);

      if (current_material.e.r || current_material.e.g ||
          current_material.e.b) {
        lights.push_back(new PointLight({.r = current_material.e.r,
                                         .g = current_material.e.g,
                                         .b = current_material.e.b},
                                        vec3(x, y, z), r));
      }
    } else if (command == "background:") {
      input >> background.r >> background.g >> background.b;
    } else if (command == "material:") {
      double ar, ag, ab, dr, dg, db, sr, sg, sb, ns, tr, tg, tb, ior;
      input >> ar >> ag >> ab >> dr >> dg >> db >> sr >> sg >> sb >> ns >> tr >>
          tg >> tb >> ior;

      current_material = {
          .a = {.r = ar, .g = ag, .b = ab},
          .d = {.r = dr, .g = dg, .b = db},
          .s = {.r = sr, .g = sg, .b = sb},
          .ns = ns,
          .t = {.r = tr, .g = tg, .b = tb},
          .ior = ior,
      };
    } else if (command == "directional_light:") {
      double r, g, b, x, y, z;
      input >> r >> g >> b >> x >> y >> z;
      lights.push_back(
          new DirectionalLight({.r = r, .g = g, .b = b}, vec3(x, y, z)));

    } else if (command == "point_light:") {
      double r, g, b, x, y, z;
      input >> r >> g >> b >> x >> y >> z;
      lights.push_back(
          new PointLight({.r = r, .g = g, .b = b}, vec3(x, y, z)));
    } else if (command == "ambient_light:") {
      double r, g, b;
      input >> r >> g >> b;color_t add = {.r = r, .g = g, .b = b};
      ambient_light = ambient_light + add;

    } else if (command == "max_depth:") {
      input >> max_depth;
    }
    printf("%lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf\n", camera.p.x, camera.p.y, camera.p.z,
           camera.d.x, camera.d.y, camera.d.z,
           camera.u.x, camera.u.y, camera.u.z,
           camera.r.x, camera.r.y, camera.r.z);
  }

  double b = -resolution.height / 2.;
  double l = -resolution.width / 2.;
  double d = resolution.height / (2 * std::tan(camera.ha));
  canvas = {.b = b, .l = l, .d = d};
  if (focal_length) {
    focal_length = resolution.width * (focal_length / 36.);
    camera.ha = std::atan(resolution.height / 2. / focal_length);
    canvas.d = focal_length;
  }
  bvh_root = new ObjTree(shapes, AXIS_X);
}

void Scene::RayTrace() {
  Image *image = new Image(resolution.width, resolution.height);
  int num_pixels = image->NumPixels();
  int width = image->Width();
  int height = image->Height();
  int image_x, image_y;

#pragma omp parallel for
  for (int t = 0; t < num_pixels; t++) {
    int i = t % width;
    int j = t / width;

    color_t c = GetColorForPixel(i, j);

    image_x = width - 1 - i;
    image_y = height - 1 - j;

    image->GetPixel(image_x, image_y)
        .SetClamp(c.r * 255., c.g * 255., c.b * 255.);
  }

  image->Write(const_cast<char *>(output_file.c_str()));
}

color_t Scene::GetColorForPixel(int i, int j) {
  Ray r = GetRayThroughCanvas(i, j);
  color_t color{0, 0, 0};
  if (dof_samples) {
    hit_t h = GetRayIntersection(r);
    vec3 focal_point;
    if (std::abs(h.t - focal_plane) < depth_of_field / 2.) {
      return EvaluateRayTree(r, 0);
    } else if (h.t < focal_plane) {
      focal_point = r.FindPoint(focal_plane - depth_of_field);
    } else {
      focal_point = r.FindPoint(focal_plane + depth_of_field);
    }

    color_t colors[dof_samples];

#pragma omp parallel for
    for (int n = 0; n < dof_samples; n++) {
      double r_x, r_y, r_z;
      double t = n / ((double)dof_samples - 1);
      double theta = (2 * dof_samples / 8.) * M_PI * t;
      double mag = aperture * std::sin(dof_samples / 1.7 * M_PI * t);
      vec3 u = camera.d;
      double c = std::cos(theta);
      double s = std::sin(theta);
      r_x = c + u.x * u.x * (1 - c) + u.x * u.y * (1 - c) - u.z * s +
            u.x * u.z * (1 - c) + u.y * s;
      r_y = u.y * u.x * (1 - c) + u.z * s + c + u.y * u.y * (1 - c) +
            u.y * u.z * (1 - c) - u.x * s;
      r_z = u.z * u.x * (1 - c) - u.y * s + u.z * u.y * (1 - c) + u.x * s + c +
            u.z * u.z * (1 - c);
      vec3 r = (vec3(r_x, r_y, r_z) + u).Normalized() * mag;
      vec3 random = camera.p - r;
      vec3 vec = (focal_point - random).Normalized();
      Ray secondary = Ray(random, vec);
      colors[n] = color + EvaluateRayTree(secondary, 0);
    }
    for (int n = 0; n < dof_samples; n++) {
      color = color + colors[n];
    }
    return color / (double)dof_samples;
  } else if (supersample) {
    for (int n = 0; n < supersample; n++) {
      double offset_x = -0.5 + rand() / (float)((RAND_MAX + 1.));
      double offset_y = -0.5 + rand() / (float)((RAND_MAX + 1.));
      r = GetRayThroughCanvas(i + offset_x, j + offset_y);
      color = color + EvaluateRayTree(r, 0);
    }
    return color / (double)supersample;
  } else if (blur_samples) {
    for (int n = 0; n < blur_samples; n++) {
      double t = n / (blur_samples - 1.);
      r.t = t;
      color = color + EvaluateRayTree(r, 0) / (double)blur_samples;
    }
    return color;
  } else {
    color = EvaluateRayTree(r, 0);
    return color;
  }
}

Ray Scene::GetRayThroughCanvas(double i, double j) {
  double u = canvas.l + (i + 0.5);
  double v = canvas.b + (j + 0.5);

  vec3 vec = camera.r * u + camera.u * v - camera.d * canvas.d;
  vec.Normalize();
  return Ray(camera.p, vec);
}

hit_t Scene::GetRayIntersection(Ray r) {
  return bvh_root->GetRayIntersection(r);
}

color_t Scene::ApplyLightingModel(hit_t hit, int depth) {
  Shape *s = hit.s;
  color_t c = s->mat.a * ambient_light + s->mat.e;

  vec3 point_hit = hit.r.FindPoint(hit.t);
  vec3 v = (hit.r.p - point_hit).Normalized();
  vec3 n = s->GetNormal(v, point_hit).Normalized();
  for (Light *light : lights) {
    vec3 l = light->L(point_hit);
    color_t diff = light->ComputeDiffuseComponent(point_hit, v, s);
    color_t spec = light->ComputeSpecularComponent(point_hit, v, s, hit.r.p);

    if (light->HasArea()) {
      int shadow_count = shadow_samples;
      for (int i = 0; i < shadow_samples; i++) {
        double r_x, r_y, r_z;
        double t = i / ((float)shadow_samples - 1);
        double theta = (2 * shadow_samples / 8.) * M_PI * t;
        double mag = static_cast<PointLight *>(light)->r *
                     std::sin(shadow_samples / 1.7 * M_PI * t);
        vec3 u = l * -1.;
        double co = std::cos(theta);
        double si = std::sin(theta);
        r_x = co + u.x * u.x * (1 - co) + u.x * u.y * (1 - co) - u.z * si +
              u.x * u.z * (1 - co) + u.y * si;
        r_y = u.y * u.x * (1 - co) + u.z * si + co + u.y * u.y * (1 - co) +
              u.y * u.z * (1 - co) - u.x * si;
        r_z = u.z * u.x * (1 - co) - u.y * si + u.z * u.y * (1 - co) +
              u.x * si + co + u.z * u.z * (1 - co);
        vec3 r = (vec3(r_x, r_y, r_z) + u).Normalized() * mag;
        vec3 random = light->pos - r;
        Ray shadow(point_hit, random, hit.r.t);
        hit_t h_shadow = GetRayIntersection(shadow);
        if (h_shadow.hit) {
          vec3 p = h_shadow.r.FindPoint(h_shadow.t);
          if ((p - point_hit).Magnitude() <
              (light->pos - point_hit).Magnitude()) {
            shadow_count--;
          }
        }
      }
      c = c + ((diff + spec) * (double)shadow_count / (double)shadow_samples);
    } else {
      Ray shadow(point_hit, l, hit.r.t);
      hit_t h_shadow = GetRayIntersection(shadow);
      if (h_shadow.hit) {
        vec3 p = h_shadow.r.FindPoint(h_shadow.t);
        if ((p - point_hit).Magnitude() <
            (light->pos - point_hit).Magnitude()) {
          continue;
        }
      }
      c = c + diff + spec;
    }
  }

  if (s->mat.s) {
    Ray reflect = Ray(point_hit, vec3::Reflect(v, n), hit.r.t);
    c = c + s->mat.s * EvaluateRayTree(reflect, depth);
  }

  if (s->mat.t) {
    double ior_i, ior_r;
    vec3 d = v * -1.;
    if (vec3::Dot(v, n) > 0) {
      ior_i = 1;
      ior_r = s->mat.ior;
    } else {
      ior_i = s->mat.ior;
      ior_r = 1;
      n = n * -1.;
    }

    vec3 refract_v =
        ((d - n * vec3::Dot(d, n)) * ior_i / ior_r) -
        n * std::sqrt(1 -
                      (ior_i * ior_i * (1 - std::pow(vec3::Dot(d, n), 2))) /
                      ior_r / ior_r);
    Ray refract = Ray(point_hit, refract_v, hit.r.t);
    // printf("ior_i = %g\n", ior_i);
    // printf("ior_r = %g\n", ior_r);
    // printf("n_refrac = %f %f %f\n", n.x, n.y, n.z);
    // printf("d = %f %f %f\n", d.x, d.y, d.z);
    // printf("Refracted ray is %f %f %f from point_hit\n", refract.v.x,
    // refract.v.y,
    //        refract.v.z);
    c = c + s->mat.t * EvaluateRayTree(refract, depth);
  }

  return c;
}

color_t Scene::EvaluateRayTree(Ray r, int current_depth) {
  current_depth++;
  hit_t hit = GetRayIntersection(r);
  if (hit.hit && current_depth <= max_depth + 1) {
    return ApplyLightingModel(hit, current_depth);
  } else {
    if (current_depth == 1) return background;
    else
      return color_t{0, 0, 0};
  }
}
