#pragma once

class vec3 {
 public:
  double x, y, z;

  vec3();
  vec3(double x_, double y_, double z_);

  static double Dot(vec3 u, vec3 v);
  static vec3 Cross(vec3 u, vec3 v);
  static double Angle(vec3 u, vec3 v);
  static double Determinant(vec3 v[3]);
  static vec3 Reflect(vec3 v, vec3 normal);

  operator bool();

  double Magnitude();
  vec3 Normalized();
  void Normalize();
};

vec3 operator+(const vec3 &u, const vec3 &v);
vec3 operator-(const vec3 &u, const vec3 &v);
vec3 operator*(const vec3 &u, double s);
vec3 operator/(const vec3 &u, double s);
