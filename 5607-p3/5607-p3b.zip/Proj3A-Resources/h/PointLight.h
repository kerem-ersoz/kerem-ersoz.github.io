#pragma once

#include "Light.h"

class PointLight : public Light {
 public:
  double r;

  PointLight(color_t intensity_, vec3 pos_);
  PointLight(color_t intensity_, vec3 pos_, double r_);

  color_t ComputeDiffuseComponent(vec3 point_hit, vec3 v, Shape *s);
  color_t ComputeSpecularComponent(vec3 point_hit, vec3 v, Shape *s,
                                   vec3 camera_p);
  bool HasArea();
  // vec3 GetRandomPoint();
};
