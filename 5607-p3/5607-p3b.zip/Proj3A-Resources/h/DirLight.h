#pragma once

#include "Light.h"

class DirectionalLight : public Light {
 public:
  DirectionalLight(color_t intensity_, vec3 pos_);

  vec3 L(vec3 point_hit);

  color_t ComputeDiffuseComponent(vec3 point_hit, vec3 v, Shape *s);
  color_t ComputeSpecularComponent(vec3 point_hit, vec3 v, Shape *s,
                                   vec3 camera_p);
};
