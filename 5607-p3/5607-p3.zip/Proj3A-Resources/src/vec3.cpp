#include "vec3.h"

#include <cmath>
#include <cstdio>

vec3::vec3() : x(0), y(0), z(0) {}

vec3::vec3(double x_, double y_, double z_) : x(x_), y(y_), z(z_) {}

double vec3::Dot(vec3 u, vec3 v) {
  // printf("Dot product of <%g, %g, %g> and <%g, %g, %g> is %g\n", u.x, u.y,
  // u.z,
  //        v.x, v.y, v.z, u.x * v.x + u.y * v.y + u.z * v.z);
  return u.x * v.x + u.y * v.y + u.z * v.z;
}

vec3 vec3::Cross(vec3 u, vec3 v) {
  // printf("Cross product of <%g, %g, %g> and <%g, %g, %g> is <%g, %g, %g>\n",
  //        u.x, u.y, u.z, v.x, v.y, v.z, u.y * v.z - u.z * v.y, u.z * v.x - u.x
  //        * v.z, u.x * v.y - u.y * v.x);
  return vec3(u.y * v.z - u.z * v.y, u.z * v.x - u.x * v.z,
                u.x * v.y - u.y * v.x);
}

double vec3::Angle(vec3 u, vec3 v) {
  return std::acos(vec3::Dot(u, v) / (u.Magnitude() * v.Magnitude()));
}

double vec3::Determinant(vec3 v[3]) {
  // v[0].x v[1].x v[2].x
  // v[0].y v[1].y v[2].y
  // v[0].z v[1].z v[2].z
  return v[0].x * (v[1].y * v[2].z - v[2].y * v[1].z) -
         v[1].x * (v[0].y * v[2].z - v[2].y * v[0].z) +
         v[2].x * (v[0].y * v[1].z - v[1].y * v[0].z);
}

vec3 vec3::Reflect(vec3 v, vec3 normal) {
  return normal * 2. * vec3::Dot(normal, v) - v;
}

double vec3::Magnitude() { return std::sqrt(x * x + y * y + z * z); }

vec3 vec3::Normalized() { return *this / Magnitude(); }

void vec3::Normalize() { *this = this->Normalized(); }

vec3::operator bool() { return x || y || z; }

vec3 operator+(const vec3 &u, const vec3 &v) {
  return vec3(u.x + v.x, u.y + v.y, u.z + v.z);
}

vec3 operator-(const vec3 &u, const vec3 &v) {
  return vec3(u.x - v.x, u.y - v.y, u.z - v.z);
}

vec3 operator*(const vec3 &u, double s) {
  return vec3(u.x * s, u.y * s, u.z * s);
}

vec3 operator/(const vec3 &u, double s) {
  return vec3(u.x / s, u.y / s, u.z / s);
}
