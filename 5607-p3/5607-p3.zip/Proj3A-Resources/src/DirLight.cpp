#include "DirLight.h"

#include <cmath>

DirectionalLight::DirectionalLight(color_t intensity_, vec3 pos_) {
  intensity = intensity_;
  pos = pos_;
}

vec3 DirectionalLight::L(vec3 point_hit) { return pos.Normalized() * -1.; }

color_t DirectionalLight::ComputeDiffuseComponent(vec3 point_hit, vec3 v,
                                                  Shape *s) {
  vec3 n = N(point_hit, v, s);
  vec3 l = L(point_hit);
  double factor = fmax(0, vec3::Dot(n, l));
  return s->mat.d * intensity * factor;
}

color_t DirectionalLight::ComputeSpecularComponent(vec3 point_hit, vec3 v,
                                                   Shape *s, vec3 camera_p) {
  vec3 r = R(point_hit, v, s);
  vec3 v1 = V(point_hit, camera_p);
  double factor = std::pow(fmax(0, vec3::Dot(r, v1)), s->mat.ns);
  return s->mat.s * intensity * factor;
}
