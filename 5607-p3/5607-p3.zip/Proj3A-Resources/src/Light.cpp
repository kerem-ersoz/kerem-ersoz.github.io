#include "Light.h"

vec3 Light::V(vec3 point_hit, vec3 camera_p) {
  return (camera_p - point_hit).Normalized();
}

vec3 Light::L(vec3 point_hit) { return (pos - point_hit).Normalized(); }

vec3 Light::N(vec3 point_hit, vec3 v, Shape *s) {
  return s->GetNormal(v, point_hit).Normalized();
}

vec3 Light::R(vec3 point_hit, vec3 v, Shape *s) {
  return vec3::Reflect(L(point_hit), N(point_hit, v, s)).Normalized();
}

bool Light::HasArea() { return false; }
