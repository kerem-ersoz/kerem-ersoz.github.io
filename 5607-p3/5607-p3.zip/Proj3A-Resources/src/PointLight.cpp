#include "PointLight.h"

#include <cmath>

PointLight::PointLight(color_t intensity_, vec3 pos_)
    : PointLight(intensity_, pos_, 0) {}

PointLight::PointLight(color_t intensity_, vec3 pos_, double r_) : r(r_) {
  intensity = intensity_;
  pos = pos_;
}

color_t PointLight::ComputeDiffuseComponent(vec3 point_hit, vec3 v,
                                            Shape *s) {
  vec3 n = N(point_hit, v, s);
  vec3 l = L(point_hit);
  double distance_factor = std::pow((pos - point_hit).Magnitude(), 2);
  double factor = fmax(0, vec3::Dot(n, l)) / distance_factor;
  return s->mat.d * intensity * factor;
}

color_t PointLight::ComputeSpecularComponent(vec3 point_hit, vec3 v,
                                             Shape *s, vec3 camera_p) {
  vec3 r = R(point_hit, v, s);
  vec3 v_ = V(point_hit, camera_p);
  double distance_factor = std::pow((pos - point_hit).Magnitude(), 2.);
  double factor =
      std::pow(fmax(0, vec3::Dot(r, v_)), s->mat.ns) / distance_factor;
  return s->mat.s * intensity * factor;
}

bool PointLight::HasArea() { return r != 0; }

// vec3 PointLight::GetRandomPoint() {
//   if (!r) {
//     return pos;
//   } else {

//   }
// }
