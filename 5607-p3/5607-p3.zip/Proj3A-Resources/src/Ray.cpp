#include "Ray.h"

#include <cmath>

Ray::Ray() : Ray(vec3(), vec3(), 0) {}
Ray::Ray(vec3 p_, vec3 v_) : Ray(p_, v_, 0) {}
Ray::Ray(vec3 p_, vec3 v_, double t_) : p(p_), v(v_), t(t_) {}

vec3 Ray::FindPoint(double t) { return v * t + p; }

void Ray::Normalize() { v.Normalize(); }
