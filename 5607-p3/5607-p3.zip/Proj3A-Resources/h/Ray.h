#pragma once

#include "vec3.h"

class Ray {
 public:
  vec3 p;
  vec3 v;
  double t;

  static constexpr double TMIN = 0.01;
  static constexpr double TMAX = 100000;

  Ray();
  Ray(vec3 p_, vec3 v_);
  Ray(vec3 p_, vec3 v_, double t);

  vec3 FindPoint(double t);
  void Normalize();
};
