#pragma once

#include "Shape.h"

class Light {
 public:
  color_t intensity;
  vec3 pos;

  // static constexpr color_t Black = {.r = 0, .g = 0, .b = 0};
  // static constexpr color_t White = {.r = 1, .g = 1, .b = 1};

  virtual vec3 V(vec3 point_hit, vec3 camera_p);
  virtual vec3 L(vec3 point_hit);
  virtual vec3 N(vec3 point_hit, vec3 v, Shape *s);
  virtual vec3 R(vec3 point_hit, vec3 v, Shape *s);

  virtual color_t ComputeDiffuseComponent(vec3 point_hit, vec3 v,
                                          Shape *s) = 0;
  virtual color_t ComputeSpecularComponent(vec3 point_hit, vec3 v, Shape *s,
                                           vec3 camera_p) = 0;
  virtual bool HasArea();
  // virtual color_t ComputeTransitiveComponent(material_t mat) = 0;
};
