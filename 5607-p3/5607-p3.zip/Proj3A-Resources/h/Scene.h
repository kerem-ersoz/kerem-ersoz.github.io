#pragma once

#include "ObjTree.h"
#include "image.h"
#include "Light.h"
#include "Ray.h"
#include "Shape.h"

// #include <iostream>
#include <string>
#include <vector>

typedef struct {
  vec3 p;
  vec3 d;
  vec3 u;
  vec3 r;
  double ha;
} camera_t;

typedef struct {
  int width, height;
} resolution_t;

typedef struct {
  color_t i;
  vec3 p;
} directional_light_t;

typedef struct {
  color_t color;
  vec3 p, d;
  double angle1, angle2;
} spot_light_t;

typedef struct {
  double b, l, d;
} canvas_t;

class Scene {
 public:
  camera_t camera;
  double focal_length;
  double focal_plane;
  double aperture;
  double depth_of_field;
  int dof_samples;
  resolution_t resolution;
  int supersample;
  int shadow_samples;
  int blur_samples;
  std::string output_file;
  std::vector<Shape *> shapes;
  std::vector<vec3 *> vertices;
  std::vector<vec3 *> normals;
  color_t background;
  std::vector<Light *> lights;
  color_t ambient_light;
  int max_depth;
  canvas_t canvas;
  ObjTree *bvh_root;

  Scene(std::istream &input);

  void RayTrace();
  color_t GetColorForPixel(int i, int j);
  Ray GetRayThroughCanvas(double i, double j);
  hit_t GetRayIntersection(Ray r);
  color_t ApplyLightingModel(hit_t hit, int depth);
  color_t EvaluateRayTree(Ray r, int current_depth);
};
