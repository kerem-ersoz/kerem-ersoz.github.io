#pragma once

#include <vector>

#include "BB.h"
#include "Shape.h"

enum Axis {
  AXIS_X,
  AXIS_Y,
  AXIS_Z,
  N_AXES,
};

class ObjTree : public Shape {
 public:
  BoundingBox *box;
  Shape *left;
  Shape *right;

  ObjTree(std::vector<Shape *> shapes, Axis axis);

  vec3 GetNormal(vec3 v, vec3 p);
  hit_t GetRayIntersection(Ray r);
  std::vector<vec3> GetExtents();
};
