#pragma once

#include "Shape.h"

class Sphere : public Shape {
 public:
  double r;

  Sphere();
  Sphere(vec3 c_, double r_, material_t mat_);
  Sphere(vec3 c_, double r_, material_t mat_, vec3 blur_);

  vec3 GetNormal(vec3 v, vec3 p);
  hit_t GetRayIntersection(Ray r);
  std::vector<vec3> GetExtents();
};
