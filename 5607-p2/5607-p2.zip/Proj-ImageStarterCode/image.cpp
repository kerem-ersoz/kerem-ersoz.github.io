//CSCI 5607 HW 2 - Image Conversion Instructor: S. J. Guy <sjguy@umn.edu>
//In this assignment you will load and convert between various image formats.
//Additionally, you will manipulate the stored image data by quantizing, cropping, and supressing channels

#include "image.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <float.h>

#include <fstream>
using namespace std;


/**
 * Image
 **/
Image::Image (int width_, int height_){

    assert(width_ > 0);
    assert(height_ > 0);

    width           = width_;
    height          = height_;
    num_pixels      = width * height;
    sampling_method = IMAGE_SAMPLING_POINT;
    
    data.raw = new uint8_t[num_pixels*4];
		int b = 0; //which byte to write to
		for (int j = 0; j < height; j++){
			for (int i = 0; i < width; i++){
				data.raw[b++] = 0;
				data.raw[b++] = 0;
				data.raw[b++] = 0;
				data.raw[b++] = 0;
			}
		}

    assert(data.raw != NULL);
}

Image::Image(const Image& src){
  width           = src.width;
  height          = src.height;
  num_pixels      = width * height;
  sampling_method = IMAGE_SAMPLING_POINT;

  data.raw = new uint8_t[num_pixels*sizeof(Pixel)];

  memcpy(data.raw, src.data.raw, num_pixels*sizeof(Pixel));
}

Image::Image(char* fname){
  int numComponents; //(e.g., Y, YA, RGB, or RGBA)

  //Load the pixels with STB Image Lib
  uint8_t* loadedPixels = stbi_load(fname, &width, &height, &numComponents, 4);
  if (loadedPixels == NULL){
    printf("Error loading image: %s", fname);
    exit(-1);
  }

  //Set image member variables
  num_pixels = width * height;
  sampling_method = IMAGE_SAMPLING_POINT;

  //Copy the loaded pixels into the image data structure
  data.raw = new uint8_t[num_pixels*sizeof(Pixel)];
  memcpy(data.raw, loadedPixels, num_pixels*sizeof(Pixel));
  free(loadedPixels);
}

Image::~Image(){
  delete[] data.raw;
  data.raw = NULL;
}

void Image::Write(char* fname){
	
	int lastc = strlen(fname);

	switch (fname[lastc-1]){
	   case 'g': //jpeg (or jpg) or png
	     if (fname[lastc-2] == 'p' || fname[lastc-2] == 'e') //jpeg or jpg
	        stbi_write_jpg(fname, width, height, 4, data.raw, 95);  //95% jpeg quality
	     else //png
	        stbi_write_png(fname, width, height, 4, data.raw, width*4);
	     break;
	   case 'a': //tga (targa)
	     stbi_write_tga(fname, width, height, 4, data.raw);
	     break;
	   case 'p': //bmp
	   default:
	     stbi_write_bmp(fname, width, height, 4, data.raw);
	}
}


void Image::Brighten (double factor){
	int x,y;
	for (x = 0 ; x < Width() ; x++){
		for (y = 0 ; y < Height() ; y++){
			Pixel p = GetPixel(x, y);
			Pixel scaled_p = p*factor;
			GetPixel(x,y) = scaled_p;
		}
	}
}

void Image::ExtractChannel(int channel) {
  for (int x = 0; x < this->Width(); ++x){
    for (int y = 0; y < this->Height(); ++y){
      Pixel p = this->GetPixel(x,y);
      if (!channel) { p.g = 0; p.b = 0; }
      else if (channel == 1) { p.r = 0; p.b = 0; }
      else { p.r = 0; p.g = 0; }
      this->SetPixel(x,y,p);
    }
  }
}


void Image::Quantize (int nbits) {
  for (int x = 0; x < this->Width(); ++x){
    for (int y = 0; y < this->Height(); ++y){
      this->SetPixel(x,y,PixelQuant(this->GetPixel(x,y),nbits));
    }
  }
}

Image* Image::Crop(int x, int y, int w, int h) {
  Image *ret = new Image(w,h);
  int origY = y;
  for (int i = 0; i < w; ++i,++x){
    for (int j = 0, y=origY; j < h; ++j,++y) {
      ret->SetPixel(i, j, this->GetPixel(x, y));
    }
  }
  return ret;
}


void Image::AddNoise (double factor){
  for (int x = 0; x < Width() * factor; ++x) {
    for (int y = 0; y < Height() * factor; ++y) {
      int randX = rand() % Width();
      int randY = rand() % Height();
      Pixel p = GetPixel(randX, randY);
      p = Pixel((rand()%255),(rand()%255),(rand()%255));
//      y & 1 ? p = Pixel(0,0,0) : p = Pixel(200,200,200);
      GetPixel(randX,randY) = p;
    }
  }
}

void Image::ChangeContrast (double factor){
  int x,y;
  double lum = 0.0;
  for (x = 0; x < Width(); ++x) {
    for (y = 0; y < Height(); ++y) {
      Pixel p = GetPixel(x, y);
      lum += ((0.3 * p.r) + (0.59 * p.g) + (0.11 * p.b));
      }
  }
  lum/=(x*y);
  for (x = 0; x < Width(); ++x) {
    for (y = 0; y < Height(); ++y) {
      Pixel p = GetPixel(x, y);
      Pixel gray = Pixel(lum,lum,lum);
      Pixel res = PixelLerp(gray,p,factor);
      GetPixel(x,y) = res;
    }
  }
}


void Image::ChangeSaturation(double factor){
  double lum = 0.0;
  for (int x = 0 ; x < Width() ; ++x) {
    for (int y = 0; y < Height(); ++y) {
      Pixel p = GetPixel(x, y);
      lum = ((0.3 * p.r) + (0.59 * p.g) + (0.11 * p.b));
      Pixel gray = Pixel(lum,lum,lum);
      Pixel res = PixelLerp(gray,p,factor);
      GetPixel(x,y) = res;
    }
  }
}


//For full credit, check that your dithers aren't making the pictures systematically brighter or darker
void Image::RandomDither (int nbits){
  this->Quantize(nbits);
  double noise = 0;
  if (nbits == 8) noise = 0;
  if (nbits == 7) noise = 0.15;
  if (nbits == 6) noise = 0.3;
  if (nbits == 5) noise = 0.45;
  if (nbits == 4) noise = 0.6;
  if (nbits == 3) noise = 0.75;
  if (nbits == 2) noise = 0.9;
  if (nbits == 1) noise = 1.05;
  this->AddNoise(noise);
}

//This bayer method gives the quantization thresholds for an ordered dither.
//This is a 4x4 dither pattern, assumes the values are quantized to 16 levels.
//You can either expand this to a larger bayer pattern. Or (more likely), scale
//the threshold based on the target quantization levels.
static int Bayer4[4][4] ={
    {15,  7, 13,  5},
    { 3, 11,  1,  9},
    {12,  4, 14,  6},
    { 0,  8,  2, 10}
};


void Image::OrderedDither(int nbits){
	/* WORK HERE */
}

/* Error-diffusion parameters */
const double
    ALPHA = 7.0 / 16.0,
    BETA  = 3.0 / 16.0,
    GAMMA = 5.0 / 16.0,
    DELTA = 1.0 / 16.0;

void Image::FloydSteinbergDither(int nbits){
  for (int y = 0; y < Height(); ++y) {
    for (int x= 0; x < Width(); ++x) {
      Pixel p = GetPixel(x, y);
      Pixel q = PixelQuant(p, nbits);
      float bError = -(p.b + q.b);
      float gError = -(p.g + q.g);
      float rError = -(p.r + q.r);
      GetPixel(x, y) = q;
      if (ValidCoord(x+1, y)) {
        Pixel p1 = GetPixel(x+1, y);
        p1.r += rError * ALPHA;
        p1.g += gError * ALPHA;
        p1.b += bError * ALPHA;
        GetPixel(x+1, y).SetClamp(p1.r, p1.g, p1.b);
      } if (ValidCoord(x+1, y+1)) {
        Pixel p2 = GetPixel(x+1, y+1);
        p2.r += rError * DELTA;
        p2.g += gError * DELTA;
        p2.b += bError * DELTA;
        GetPixel(x+1, y+1).SetClamp(p2.r, p2.g, p2.b);
      } if (ValidCoord(x-1, y+1)) {
        Pixel p3 = GetPixel(x-1, y+1);
        p3.r += rError * BETA;
        p3.g += gError * BETA;
        p3.b += bError * BETA;
        GetPixel(x-1, y+1).SetClamp(p3.r, p3.g, p3.b);
      } if (ValidCoord(x, y+1)) {
        Pixel p4 = GetPixel(x, y+1);
        p4.r += rError * GAMMA;
        p4.g += gError * GAMMA;
        p4.b += bError * GAMMA;
        GetPixel(x, y+1).SetClamp(p4.r, p4.g, p4.b);
      }
    }
  }
}

int ValClamp(int a, int b, int c) {
  if (a < b) return b;
  if (a > c) return c;
  return a;
}

void Image::Blur(int n){
	Image* imgCpy = new Image(*this); // This is will copying the image, so you can read the orginal values for filtering
	                                    //  ... don't forget to delete the copy!
  double filter[n][n];
  int filterX, filterY;
  double filterSum = 0;
  double sigma = n;
  for (filterX = 0; filterX < n; filterX++) {
    for (filterY = 0; filterY < n; filterY++) {
      float x = filterX + 0.5 - n / 2.;
      float y = filterY + 0.5 - n / 2.;
      filter[filterX][filterY] = exp(-(pow(x, 2) / (2 * pow(sigma, 2)) + pow(y, 2) / (2 * pow(sigma, 2))));
      filterSum += filter[filterX][filterY];
    }
  }
  int x, y;
  for (x = 0; x < imgCpy->Width(); x++) {
    for (y = 0; y < imgCpy->Height(); y++) {
      float rNew = 0, gNew = 0, bNew = 0;
      for (int filterX = 0; filterX < n; filterX++) {
        for (int filterY = 0; filterY < n; filterY++) {
          int ix = x + filterX - n / 2;
          int iy = y + filterY - n / 2;
          ix = ValClamp(ix, 0, Width() - 1);
          iy = ValClamp(iy, 0, Height() - 1);
          Pixel p = GetPixel(ix, iy);
          rNew += p.r * filter[filterX][filterY] / filterSum;
          gNew += p.g * filter[filterX][filterY] / filterSum;
          bNew += p.b * filter[filterX][filterY] / filterSum;
        }
      }
      imgCpy->GetPixel(x, y).SetClamp(rNew, gNew, bNew);
    }
  }
  *this = *imgCpy;
}

void Image::Sharpen(int n){
  Image* imgNew = new Image(Width(), Height());
  Image imgCpy = Image(*this);
  imgCpy.Blur(n);
  for (int x = 0; x < Width(); x++) {
    for (int y = 0; y < Height(); y++) {
      imgNew->GetPixel(x, y) = PixelLerp(GetPixel(x, y), imgCpy.GetPixel(x, y), -1);
    }
  }
  *this = *imgNew;
}

void Image::EdgeDetect(){
  Image* imgCpy = new Image(*this); // This is will copying the image, so you can read the orginal values for filtering
  double f[3][3] = {{-1,-1,-1},{-1,8,-1},{-1,-1,-1}};
  int filterWidth = 3;

  for (int x = 0; x < Width(); x++) {
    for (int y = 0; y < Height(); y++) {
      float Rnew = 0, Gnew = 0, Bnew = 0;
      for (int filterX = 0; filterX < filterWidth; ++filterX) {
        for (int filterY = 0; filterY < filterWidth; ++filterY) {
          int ix = x + filterX - filterWidth / 2;
          int iy = y + filterY - filterWidth / 2;
          ix = ValClamp(ix, 0, Width() - 1);
          iy = ValClamp(iy, 0, Height() - 1);
          Pixel p = GetPixel(ix, iy);
          Rnew += p.r * f[filterX][filterY];
          Gnew += p.g * f[filterX][filterY];
          Bnew += p.b * f[filterX][filterY];
        }
      }
      imgCpy->GetPixel(x, y).SetClamp(Rnew, Gnew, Bnew);
    }
  }
  *this = *imgCpy;
}

Image* Image::Scale(double sx, double sy){
  int newWidth = (int)(sx * Width());
  int newHeight = (int)(sy * Height());
  Image *imgNew = new Image(newWidth, newHeight);
  for (int x = 0; x < newWidth; x++) {
    for (int y = 0; y < newHeight; y++) {
      imgNew->GetPixel(x, y) = Sample(x / sx, y / sy);
    }
  }
  return imgNew;
}

Image* Image::Rotate(double angle){
  angle *= M_PI / 180.;
  int newWidth = Height() * std::abs(std::sin(angle)) + Width() * std::abs(std::sin(M_PI / 2 - angle));
  int newHeight = Height() * std::abs(std::cos(angle)) + Width() * std::abs(std::cos(M_PI / 2 - angle));
  Image *img = new Image(newWidth, newHeight);
  int xDiff = (newWidth - Width()) / 2;
  int yDiff = (newHeight - Height()) / 2;
  int midWidth = Width() / 2;
  int midHeight = Height() / 2;
  for (int x = 0; x < newWidth; x++) {
    for (int y = 0; y < newHeight; y++) {
      int newX = x - xDiff;
      int newY = y - yDiff;
      int xSample = (newX - midWidth) * std::cos(angle) - (newY- midHeight) * std::sin(angle) + midWidth;
      int ySample = (newX - midWidth) * std::sin(angle) + (newY - midHeight) * std::cos(angle) + midHeight;
      if (!ValidCoord(xSample, ySample)) {
        img->GetPixel(x, y).Set(0, 0, 0, 0);
      } else {
        img->GetPixel(x, y) = Sample(xSample, ySample);
      }
    }
  }
  return img;
}

void Image::Fun(){
  Quantize(3);
  for (int x = 0; x < Width()-24; x+=3) {
    for (int y = 0; y < Height()-24; y+=3) {
      int xRand = rand() % (Width()-24);
      int yRand = rand() % (Height()-24);
      for (int z = 0; z < 24; ++z){
        this->GetPixel(x,y+z) = this->GetPixel(xRand+z, y);
        this->GetPixel(x+z,y) = this->GetPixel(x, yRand+z);
      }
    }
  }
}

/**
 * Image Sample
 **/
void Image::SetSamplingMethod(int method){
   assert((method >= 0) && (method < IMAGE_N_SAMPLING_METHODS));
   sampling_method = method;
}


Pixel Image::Sample (double u, double v){
  Pixel pxNew;
  switch (sampling_method) {
    case IMAGE_SAMPLING_POINT: {
      int xNew = (int)(u+0.5);
      int yNew = (int)(v+0.5);
      if (ValidCoord(xNew, yNew)) {
        pxNew = GetPixel(xNew, yNew);
      } else {
        pxNew = Pixel();
      }
      break;
    }
    case IMAGE_SAMPLING_BILINEAR: {
      double d;
      if (!modf(u, &d) && !modf(v, &d)) {
        pxNew = GetPixel((int)u, (int)v);
        break;
      }
      if (!ValidCoord(ceil(u), ceil(v))) {
        pxNew = Pixel();
        break;
      }
      Pixel p1 = GetPixel(floor(u), floor(v));
      Pixel p2 = GetPixel(ceil(u), floor(v));
      Pixel p3 = GetPixel(floor(u), ceil(v));
      Pixel p4 = GetPixel(ceil(u), ceil(v));
      if (u == floor(u)) {
        pxNew = p1*(1-(v-floor(v))) + p3*(1-(ceil(v)-v));
        break;
      } else if (v == floor(v)) {
        pxNew = p1*(1-(u-floor(u))) + p2*(1-(ceil(u)-u));
        break;
      }
      Pixel p5 = p1*(1-(u-floor(u))) + p2*(1-(ceil(u)-u));
      Pixel p6 = p3*(1-(u-floor(u))) + p4*(1-(ceil(u)-u));
      Pixel pxRes = p5*(1-(v-floor(v))) + p6*(1-(ceil(v)-v));
      pxNew = pxRes;
      break;
    }
    case IMAGE_SAMPLING_GAUSSIAN: {
      int r = 2;
      float sigma = r;
      float rNew = 0,gNew = 0,bNew = 0;
      float pxDistSum = 0;
      for (int i = -r; i < r; ++i) {
        for (int j = -r; j < r; ++j) {
          int x = (int)(u + i + 0.5);
          int y = (int)(v + j + 0.5);
          if (ValidCoord(x, y) && i*i+j*j <= r*r) {
            Pixel p = GetPixel(x, y);
            float pxDist = exp(-(pow(u-x, 2) / (2 * pow(sigma, 2)) + pow(v-y, 2) / (2 * pow(sigma, 2))));
            pxDistSum += pxDist;
            rNew += p.r*pxDist;
            gNew += p.g*pxDist;
            bNew += p.b*pxDist;
          }
        }
      }
      rNew /= pxDistSum;
      gNew /= pxDistSum;
      bNew /= pxDistSum;
      pxNew = Pixel(rNew, gNew, bNew);
      break;
    }
  }
  return pxNew;
}