
//UMN CSCI 5607 2D Geometry Library Homework [HW0]
//TODO: For the 18 functions below, replace their sub function with a working version that matches the desciption.

#ifndef OPS_H
#define OPS_H

#include "pga.h"
#include <vector>
#include <algorithm>

//Displace a point p on the direction d
//The result is a point
Point2D move(Point2D p, Dir2D d){
  return Point2D(p.x+d.x,p.y+d.y);
}

//Compute the displacement vector between points p1 and p2
//The result is a direction
Dir2D displacement(Point2D p1, Point2D p2){
  return Dir2D(p1.x-p2.x,p2.y-p2.y);
}

//Compute the distance between points p1 and p2
//The result is a scalar
float dist(Point2D p1, Point2D p2){
  return sqrt(pow((p1.x - p2.x),2) + pow((p1.y-p2.y),2)); //Wrong, fix me...
}

//Compute the perpendicular distance from the point p the the line l
//The result is a scalar
float dist(Line2D l, Point2D p){
  return vee(l.normalized(),p.normalized());
}

//Compute the perpendicular distance from the point p the the line l
//The result is a scalar
float dist(Point2D p, Line2D l){
  return vee(p.normalized(),l.normalized());
}

//Compute the intersection point between lines l1 and l2
//You may assume the lines are not parallel
//The results is a a point that lies on both lines
Point2D intersect(Line2D l1, Line2D l2){
  return wedge(l1,l2);
}

//Compute the line that goes through the points p1 and p2
//The result is a line
Line2D join(Point2D p1, Point2D p2){
  return vee(p1,p2);
}

//Compute the projection of the point p onto line l
//The result is the closest point to p that lies on line l
Point2D project(Point2D p, Line2D l){
  return MultiVector(l).times(dot(p,l));
}

//Compute the projection of the line l onto point p
//The result is a line that lies on point p in the same direction of l
Line2D project(Line2D l, Point2D p){
  return MultiVector(p).times(dot(p,l));
}

//Compute the angle point between lines l1 and l2
//You may assume the lines are not parallel
//The results is a scalar
float angle(Line2D l1, Line2D l2){
  return acosf(dot(l1.normalized(), l2.normalized()));
}

//Compute if the line segment p1->p2 intersects the line segment a->b
//The result is a boolean
bool segmentSegmentIntersect(Point2D p1, Point2D p2, Point2D a, Point2D b){
  if ((((p1.y - p2.y) * (a.x - p1.x) + (p2.x - p1.x) * (a.y - p1.y)) * ((p1.y - p2.y) * (b.x - p1.x) + (p2.x - p1.x) * (b.y - p1.y))) < 0) return true;
  return false;
}

//Compute the area of the triangle t1,t2,t3
//The result is a scalar
float areaTriangle(Point2D t1, Point2D t2, Point2D t3){
  // return vee(t1.normalized(),t2.normalized(),t3.normalized())/2.0;
  return fabs((t1.x * (t2.y - t3.y) + t2.x * (t3.y - t1.y) + t3.x * (t1.y - t2.y))/2.0);
}

bool pointOnTriCorner(Point2D p, Point2D t1, Point2D t2, Point2D t3){
  float dist1 = dist(p,t1);
  float dist2 = dist(p,t2);
  float dist3 = dist(p,t3);
  printf("dist1 %lf, dist2 %lf, dist3 %lf\n",dist1,dist2,dist3);
  return (dist1 <= 0.03 || dist2 <= 0.03 || dist3 <= 0.03);
}

//Compute if the point p lies inside the triangle t1,t2,t3
//Your code should work for both clockwise and counterclockwise windings
//The result is a bool
unsigned short pointInTriangle(Point2D p, Point2D t1, Point2D t2, Point2D t3){
  float area1 = areaTriangle(t1,p,t2);
  float area2 = areaTriangle(t2,p,t3);
  float area3 = areaTriangle(t3,p,t1);
  float totArea = area1 + area2 + area3;
  float triArea = areaTriangle(t1,t2,t3);
  if (totArea > triArea * 1.1) return 0; // outside the rectangle
  else if (pointOnTriCorner(p,t1,t2,t3)) return 1; // on a corner
  else if (area1 < 0.005 || area2 < 0.005 || area3 < 0.005) {
    return 2; // on an edge
  }
  else return 3; // inside the rectangle
}

bool pointOnCorner(Point2D p, Point2D t1, Point2D t2, Point2D t3, Point2D t4){
  float dist1 = dist(p,t1);
  float dist2 = dist(p,t2);
  float dist3 = dist(p,t3);
  float dist4 = dist(p,t4);
  return (dist1 <= 0.03 || dist2 <= 0.03 || dist3 <= 0.03 || dist4 <= 0.03);
}

float areaRectangle(Point2D t1, Point2D t2, Point2D t3, Point2D t4){
  return fabs(vee(t1,t2).magnitude()) * fabs(vee(t3,t4).magnitude());
}

//Compute if the point p lies inside the square t1,t2,t3,t4
// This routine was inspired by the first answer to this SO question:
// https://math.stackexchange.com/questions/190111/how-to-check-if-a-point-is-inside-a-rectangle
unsigned short pointInSquare(Point2D p, Point2D t1, Point2D t2, Point2D t3, Point2D t4){
  float area1 = areaTriangle(t1,p,t4);
  float area2 = areaTriangle(t4,p,t3);
  float area3 = areaTriangle(t3,p,t2);
  float area4 = areaTriangle(p,t2,t1);
  float totArea = area1 + area2 + area3 + area4;
  float rectArea = areaRectangle(t1,t2,t3,t4);
  if (totArea > rectArea * 1.1) return 0; // outside the rectangle
  else if (pointOnCorner(p,t1,t2,t3,t4)) return 1; // on a corner
  else if (area1 < 0.005 || area2 < 0.005 || area3 < 0.005 || area4 < 0.005) {
    return 2; // on an edge
  }
  else return 3; // inside the rectangle
}

//Compute the distance from the point p to the triangle t1,t2,t3 as defined
//by it's distance from the edge closest to p.
//The result is a scalar
float pointTriangleEdgeDist(Point2D p, Point2D t1, Point2D t2, Point2D t3){
  std::vector<float> vec;
  vec.push_back(fabs(dist(p,join(t1,t2))));
  vec.push_back(fabs(dist(p,join(t2,t3))));
  vec.push_back(fabs(dist(p,join(t3,t1))));
  return *std::min_element(vec.begin(),vec.end());
}

//Compute the distance from the point p to the closest of three corners of
// the triangle t1,t2,t3
//The result is a scalar
float pointTriangleCornerDist(Point2D p, Point2D t1, Point2D t2, Point2D t3){
  std::vector<float> vec;
  vec.push_back(fabs(dist(p,t1)));
  vec.push_back(fabs(dist(p,t2)));
  vec.push_back(fabs(dist(p,t3)));
  return *std::min_element(vec.begin(),vec.end());
}

//Compute if the quad (p1,p2,p3,p4) is convex.
//Your code should work for both clockwise and counterclockwise windings
//The result is a boolean
bool isConvex_Quad(Point2D p1, Point2D p2, Point2D p3, Point2D p4){
  return segmentSegmentIntersect(p1,p3,p2,p4);
}

//Compute the reflection of the point p about the line l
//The result is a point
Point2D reflect(Point2D p, Line2D l){
  MultiVector line = MultiVector(l);
  MultiVector ret = line.times(MultiVector(p)).times(line);
  return Point2D(ret);
}

//Compute the reflection of the line d about the line l
//The result is a line
Line2D reflect(Line2D d, Line2D l){
  MultiVector line = MultiVector(l);
  MultiVector ret = line.times(MultiVector(d)).times(line);
  return Line2D(ret).normalized();
}

#endif //PROJ1_RESOURCES_OPS_H
